#ifndef CONFIG_H
#define CONFIG_H

#define LED_PIN 13

#define BUTTON_PIN 2

// Define the baud rate for the serial communication
#define BAUDRATE 115200

#define BUTTON_REFRESH_TIME 100
#define RESET 0

#endif