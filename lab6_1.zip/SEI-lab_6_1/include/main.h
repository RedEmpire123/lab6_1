#ifndef MAIN_H
#define MAIN_H

#include <Arduino.h>
#include "my_task.h"
#include "own_stdio.h"

uint8_t globalCounter = 2;
uint8_t bufferCounter = 0;

#endif