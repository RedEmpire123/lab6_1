#include "main.h"

void setup(void) 
{
  setUp();
}

void loop(void) 
{
  buttonPressTask();
}